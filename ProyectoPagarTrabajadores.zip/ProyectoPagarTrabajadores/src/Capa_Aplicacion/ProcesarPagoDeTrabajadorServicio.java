
package Capa_Aplicacion;


public class ProcesarPagoDeTrabajadorServicio {
    
  public void ProcesarPagoDeTrabajador(){
  
  }
}
