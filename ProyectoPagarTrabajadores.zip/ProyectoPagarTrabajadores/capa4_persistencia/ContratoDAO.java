/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capa4_persistencia;

import capa3_dominio.Contrato;

/**
 *
 * @author NATALI
 */
public class ContratoDAO {
    
    private GestorJDBC gestorJDBC;
    
    public ContratoDAO(GestorJDBC gestorJDBC) {
        this.gestorJDBC = gestorJDBC;
    }
    
    public void Crear(Contrato contrato) throws Exception{
        
    }
    
    public void guardar(Contrato contrato) throws Exception{
        
    }
    
    public void modificar(Contrato contrato) throws Exception{
        
    }
}
