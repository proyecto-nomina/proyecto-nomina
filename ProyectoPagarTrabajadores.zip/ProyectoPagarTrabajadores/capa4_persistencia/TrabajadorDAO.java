/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capa4_persistencia;

import capa3_dominio.Trabajador;

/**
 *
 * @author NATALI
 */
public class TrabajadorDAO {
    private GestorJDBC gestorJDBC;
    
    
    public TrabajadorDAO(GestorJDBC gestorJDBC) {
        this.gestorJDBC = gestorJDBC;
    }
    
    public void crear(Trabajador trabajador) throws Exception{
        
    }
    public void guardar(Trabajador trabajador) throws Exception{
        
    }
    public void modifica(Trabajador trabajador) throws Exception{
        
    }
    
}
